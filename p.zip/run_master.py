import time
from profinet_controller import ProfinetController

# Имя сетевого интерфейса (из Wireshark: \Device\NPF_...)
# Для scapy в Windows часто нужно передавать именно это имя,
# или человекочитаемое имя, если scapy его подхватит.
IFACE = "Ethernet 3" 
TARGET_IP = "192.168.0.101"
GSDML_FILE = "GSDML_V2_42_3S_Smart_Software_Solutions_GmbH_Codesys_PLC_20210927.xml"

def main():
    print(f"Запуск PROFINET Controller Simulation...")
    
    try:
        # Инициализация контроллера
        # Скрипт сам распарсит GSDML и подготовит структуры данных
        controller = ProfinetController(
            interface=IFACE,
            device_ip=TARGET_IP,
            gsdml_path=GSDML_FILE
        )
        
        # Здесь мы должны добавить модули, которые настроены в CODESYS.
        # В этой библиотеке модули добавляются по их ID из GSDML.
        # В вашем случае (исходя из логов):
        # DAP модуль (Слот 0) - IDD_1 (или берется автоматически)
        # Input 8Bit - IDM_1
        # Output 8Bit - IDM_2
        
        # Добавляем модули в слоты 1 и 2 (в формате: Слот, "Module ID из GSDML")
        controller.add_module(1, "IDM_1") 
        controller.add_module(2, "IDM_2")

        # Если вы переделали на 64 байта (например, это IDM_64x1), то пишите его:
        # controller.add_module(1, "IDM_64x1") 

        print("Подключение к CODESYS...")
        if controller.connect():
            print("Успешное подключение! Начинаем циклический обмен.")
            
            counter = 0
            while True:
                # Чтение данных (из слота 2 - Output_8Bit)
                # Библиотека возвращает словарь с данными
                input_data = controller.read_data(slot=2)
                if input_data:
                    print(f"[CODESYS -> Python] Прочитано: {input_data}")

                # Запись данных (в слот 1 - Input_8Bit)
                # Записываем байты
                data_to_write = bytes([counter % 256])
                controller.write_data(slot=1, data=data_to_write)
                print(f"[Python -> CODESYS] Записано: {counter % 256}")

                counter += 1
                time.sleep(1.0)
        else:
            print("Не удалось установить соединение (RPC/Connect отвергнут).")
            
    except KeyboardInterrupt:
        print("\nОстановка...")
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"Ошибка: {e}")
    finally:
        if 'controller' in locals():
            controller.disconnect()
            print("Отключено.")

if __name__ == "__main__":
    main()