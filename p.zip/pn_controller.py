import time
import logging
from profinet import ProfinetDevice
from profinet.rpc import epm_lookup, UUID_PNIO_DEVICE

logging.basicConfig(level=logging.INFO, format='%(message)s')

IFACE_NAME = "Ethernet 3"
TARGET_NAME = "siprotec-sim-test"  

def main():
    print(f"Поиск устройства '{TARGET_NAME}'...")
    
    try:
        device = ProfinetDevice.discover(
            identifier=TARGET_NAME,
            interface=IFACE_NAME,
            timeout=5.0
        )
        print(f"Устройство найдено: {device.name} ({device.ip})")

        # --- МАГИЯ: ЗАПРАШИВАЕМ ПРАВИЛЬНЫЙ UUID У САМОГО CODESYS ---
        print("\nОпрашиваем Endpoint Mapper (EPM) устройства...")
        try:
            endpoints = epm_lookup(device.ip)
            correct_uuid = None
            
            for ep in endpoints:
                print(f" - Найден сервис: {ep.annotation} (Port: {ep.port})")
                print(f"   Interface UUID: {ep.interface_uuid}")
                print(f"   Object UUID: {ep.object_uuid}")
                
                # Ищем сервис PROFINET IO Device
                if ep.interface_uuid.lower() == UUID_PNIO_DEVICE.lower():
                    correct_uuid = ep.object_uuid
                    print(f"   >>> Это нужный нам сервис! Берем этот UUID.")
            
            if not correct_uuid:
                print("\nВНИМАНИЕ: Сервис PNIO Device не найден в EPM!")
                print("Попробуем использовать системный хак (переворот байтов)...")
                # CODESYS иногда использует Little-Endian для первых полей UUID
                info = device._info
                b = bytes([
                    0x01, 0x00, 0x71, 0x82, 0xd1, 0x11, 0x97, 0x6c, 
                    info.device_low, info.device_high, info.vendor_low, info.vendor_high,
                    0, 0, 0, 0
                ])
                correct_uuid_bytes = b
            else:
                import uuid
                correct_uuid_bytes = uuid.UUID(correct_uuid).bytes

            print("="*50)
            
            # Подменяем UUID перед коннектом
            device._rpc = __import__('profinet.rpc', fromlist=['RPCCon']).RPCCon(
                info=device._info, 
                timeout=device._timeout
            )
            device._rpc.remote_object_uuid = correct_uuid_bytes
            print(f"Установили правильный Object UUID: {correct_uuid_bytes.hex()}")

        except Exception as epm_err:
            print(f"Ошибка при опросе EPM: {epm_err}")
            return
            
        print("Устанавливаем ациклический RPC канал связи...")
        device._rpc.connect(device._src_mac)
        device._connected = True
        print("RPC соединение установлено успешно!")

        counter = 0
        while True:
            try:
                # Читаем данные (Слот 1)
                read_data = device.read(slot=1, subslot=1, index=0x8029)
                if read_data:
                    print(f"[CODESYS -> Python] Прочитано (Slot 1): {read_data[-1]}")
                    
                # Пишем данные (Слот 2)
                device.write(slot=2, subslot=1, index=0x8028, data=bytes([counter % 256]))
                print(f"[Python -> CODESYS] Записано (Slot 2): {counter % 256}")
                
            except Exception as io_err:
                print(f"Ошибка обмена: {io_err}")
                
            counter += 1
            print("-" * 30)
            time.sleep(1.0)
            
    except KeyboardInterrupt:
        print("\nОстановка...")
    except Exception as e:
        print(f"\nОшибка: {e}")
    finally:
        if 'device' in locals() and hasattr(device, 'disconnect'):
            try: device.disconnect()
            except: pass

if __name__ == "__main__":
    main()